// Signatures for functional components and custom hooks.
export const signaturesForType = new WeakMap();
