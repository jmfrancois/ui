import { options } from "/node_modules/.vite/deps/preact.js?v=8b7c1560";
import {
  CATCH_ERROR_OPTION,
  COMPONENT_DIRTY,
  VNODE_COMPONENT,
} from "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+core@1.5.2_preact@10.19.3/node_modules/@prefresh/core/src/constants.js?v=6c2cbf74";

const oldCatchError = options[CATCH_ERROR_OPTION];
options[CATCH_ERROR_OPTION] = (error, vnode, oldVNode) => {
  if (vnode[VNODE_COMPONENT] && vnode[VNODE_COMPONENT][COMPONENT_DIRTY]) {
    vnode[VNODE_COMPONENT][COMPONENT_DIRTY] = false;
  }

  if (oldCatchError) oldCatchError(error, vnode, oldVNode);
};
