import {
  _,
  a,
  l,
  u
} from "/node_modules/.vite/deps/chunk-2V2MZTZA.js?v=6c2cbf74";
import {
  g
} from "/node_modules/.vite/deps/chunk-4Y5524DS.js?v=6c2cbf74";
export {
  g as Fragment,
  u as jsx,
  l as jsxAttr,
  u as jsxDEV,
  _ as jsxEscape,
  a as jsxTemplate,
  u as jsxs
};
//# sourceMappingURL=preact_jsx-dev-runtime.js.map
