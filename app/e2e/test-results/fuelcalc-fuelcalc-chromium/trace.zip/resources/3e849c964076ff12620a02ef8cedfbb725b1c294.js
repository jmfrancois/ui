// all vnodes referencing a given constructor
export const vnodesForComponent = new WeakMap();
export const mappedVNodes = new WeakMap();
