import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Footer.tsx");        import "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+core@1.5.2_preact@10.19.3/node_modules/@prefresh/core/src/index.js?v=6c2cbf74";        import { flush as flushUpdates } from "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+utils@1.2.0/node_modules/@prefresh/utils/src/index.js?v=6c2cbf74";        let prevRefreshReg;        let prevRefreshSig;        if (import.meta.hot) {          prevRefreshReg = self.$RefreshReg$ || (() => {});          prevRefreshSig = self.$RefreshSig$ || (() => (type) => type);          self.$RefreshReg$ = (type, id) => {            self.__PREFRESH__.register(type, "/Users/jeanmichel.francois/github/jmfrancois/ui/app/fuelcalc/src/components/Footer.tsx" + " " + id);          };          self.$RefreshSig$ = () => {            let status = 'begin';            let savedType;            return (type, key, forceReset, getCustomHooks) => {              if (!savedType) savedType = type;              status = self.__PREFRESH__.sign(type || savedType, key, forceReset, getCustomHooks, status);              return type;            };          };        }        var _jsxFileName = "/Users/jeanmichel.francois/github/jmfrancois/ui/app/fuelcalc/src/components/Footer.tsx";
import { jsxDEV as _jsxDEV } from "/node_modules/.vite/deps/preact_jsx-dev-runtime.js?v=d572fda9";
export function Footer() {
  return _jsxDEV("footer", {
    className: "pb-8",
    children: _jsxDEV("p", {
      children: ["This website has been done for simracing. It provides a quick form to compute the needed fuel for a race. Fill your laptime, race length and consumption and you have and you will have the total fuel needed. It works great with", " ", _jsxDEV("a", {
        href: "https://assettocorsa.gg/assetto-corsa-competizione/",
        className: "font-medium text-red-600 hover:underline dark:text-red-500",
        children: "assetto corsa competizione"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 5
      }, this), "."]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 4,
      columnNumber: 4
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 3,
    columnNumber: 3
  }, this);
}
_c = Footer;
var _c;
$RefreshReg$(_c, "Footer");

        if (import.meta.hot) {
          self.$RefreshReg$ = prevRefreshReg;
          self.$RefreshSig$ = prevRefreshSig;
          import.meta.hot.accept((m) => {
            try {
              flushUpdates();
            } catch (e) {
              self.location.reload();
            }
          });
        }
      
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFBTyxnQkFBU0EsU0FBUztFQUN4QixPQUNDQyxRQUFBO0lBQVFDLFdBQVU7SUFBTUMsVUFDdkJGLFFBQUE7TUFBQUUsVUFBQSxDQUFHLHNPQUllLEtBQ2pCRixRQUFBO1FBQ0NHLE1BQUs7UUFDTEYsV0FBVTtRQUE0REMsVUFDdEU7TUFFRDtRQUFBRSxVQUFBQztRQUFBQyxZQUFBO1FBQUFDLGNBQUE7TUFBQSxPQUFHLEdBQUMsR0FFTDtJQUFBO01BQUFILFVBQUFDO01BQUFDLFlBQUE7TUFBQUMsY0FBQTtJQUFBLE9BQUc7RUFBQztJQUFBSCxVQUFBQztJQUFBQyxZQUFBO0lBQUFDLGNBQUE7RUFBQSxPQUNHO0FBRVY7QUFBQUMsRUFBQSxHQWxCZ0JUO0FBQUFBO0FBQUFBIiwibmFtZXMiOlsiRm9vdGVyIiwiX2pzeERFViIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwiaHJlZiIsImZpbGVOYW1lIiwiX2pzeEZpbGVOYW1lIiwibGluZU51bWJlciIsImNvbHVtbk51bWJlciIsIl9jIl0sInNvdXJjZXMiOlsiRm9vdGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZnVuY3Rpb24gRm9vdGVyKCkge1xuXHRyZXR1cm4gKFxuXHRcdDxmb290ZXIgY2xhc3NOYW1lPVwicGItOFwiPlxuXHRcdFx0PHA+XG5cdFx0XHRcdFRoaXMgd2Vic2l0ZSBoYXMgYmVlbiBkb25lIGZvciBzaW1yYWNpbmcuIEl0IHByb3ZpZGVzIGEgcXVpY2sgZm9ybSB0b1xuXHRcdFx0XHRjb21wdXRlIHRoZSBuZWVkZWQgZnVlbCBmb3IgYSByYWNlLiBGaWxsIHlvdXIgbGFwdGltZSwgcmFjZSBsZW5ndGggYW5kXG5cdFx0XHRcdGNvbnN1bXB0aW9uIGFuZCB5b3UgaGF2ZSBhbmQgeW91IHdpbGwgaGF2ZSB0aGUgdG90YWwgZnVlbCBuZWVkZWQuIEl0XG5cdFx0XHRcdHdvcmtzIGdyZWF0IHdpdGh7JyAnfVxuXHRcdFx0XHQ8YVxuXHRcdFx0XHRcdGhyZWY9XCJodHRwczovL2Fzc2V0dG9jb3JzYS5nZy9hc3NldHRvLWNvcnNhLWNvbXBldGl6aW9uZS9cIlxuXHRcdFx0XHRcdGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtcmVkLTYwMCBob3Zlcjp1bmRlcmxpbmUgZGFyazp0ZXh0LXJlZC01MDBcIlxuXHRcdFx0XHQ+XG5cdFx0XHRcdFx0YXNzZXR0byBjb3JzYSBjb21wZXRpemlvbmVcblx0XHRcdFx0PC9hPlxuXHRcdFx0XHQuXG5cdFx0XHQ8L3A+XG5cdFx0PC9mb290ZXI+XG5cdClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2plYW5taWNoZWwuZnJhbmNvaXMvZ2l0aHViL2ptZnJhbmNvaXMvdWkvYXBwL2Z1ZWxjYWxjL3NyYy9jb21wb25lbnRzL0Zvb3Rlci50c3gifQ==