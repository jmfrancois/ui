import "/node_modules/.vite/deps/preact_debug.js?v=d572fda9";
var _jsxFileName = "/Users/jeanmichel.francois/github/jmfrancois/ui/app/fuelcalc/src/index.tsx";
import { render } from "/node_modules/.vite/deps/preact.js?v=8b7c1560";
import "/src/style.css";
import { App } from "/src/components/App.tsx";
import { jsxDEV as _jsxDEV } from "/node_modules/.vite/deps/preact_jsx-dev-runtime.js?v=d572fda9";
render(_jsxDEV(App, {}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 6,
  columnNumber: 8
}, this), document.getElementById("app"));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLG1CQUFlO0FBRWYsU0FBTyxjQUFhO0FBQ3BCO0FBQXNDLFNBQUFBLFdBQUFDO0FBRXRDQyxTQUFPRCxVQUFJO09BQUFFLFFBQUFDLFNBQUE7QUFBQSxFQUFBQyxVQUFBO0FBQUEsRUFBQUMsWUFBQTtBQUFBLGdCQUFLQyIsIm5hbWVzIjpbImpzeERFViIsIl9qc3hERVYiLCJyZW5kZXIiLCJmaWxlTmFtZSIsIl9qc3hGaWxlTmFtZSIsImxpbmVOdW1iZXIiLCJjb2x1bW5OdW1iZXIiLCJkb2N1bWVudCJdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyByZW5kZXIgfSBmcm9tICdwcmVhY3QnXG5cbmltcG9ydCAnLi9zdHlsZS5jc3MnXG5pbXBvcnQgeyBBcHAgfSBmcm9tICcuL2NvbXBvbmVudHMvQXBwJ1xuXG5yZW5kZXIoPEFwcCAvPiwgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FwcCcpKVxuIl0sImZpbGUiOiIvVXNlcnMvamVhbm1pY2hlbC5mcmFuY29pcy9naXRodWIvam1mcmFuY29pcy91aS9hcHAvZnVlbGNhbGMvc3JjL2luZGV4LnRzeCJ9