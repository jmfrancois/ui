import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Header.tsx");        import "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+core@1.5.2_preact@10.19.3/node_modules/@prefresh/core/src/index.js?v=6c2cbf74";        import { flush as flushUpdates } from "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+utils@1.2.0/node_modules/@prefresh/utils/src/index.js?v=6c2cbf74";        let prevRefreshReg;        let prevRefreshSig;        if (import.meta.hot) {          prevRefreshReg = self.$RefreshReg$ || (() => {});          prevRefreshSig = self.$RefreshSig$ || (() => (type) => type);          self.$RefreshReg$ = (type, id) => {            self.__PREFRESH__.register(type, "/Users/jeanmichel.francois/github/jmfrancois/ui/app/fuelcalc/src/components/Header.tsx" + " " + id);          };          self.$RefreshSig$ = () => {            let status = 'begin';            let savedType;            return (type, key, forceReset, getCustomHooks) => {              if (!savedType) savedType = type;              status = self.__PREFRESH__.sign(type || savedType, key, forceReset, getCustomHooks, status);              return type;            };          };        }        var _jsxFileName = "/Users/jeanmichel.francois/github/jmfrancois/ui/app/fuelcalc/src/components/Header.tsx";
import { jsxDEV as _jsxDEV } from "/node_modules/.vite/deps/preact_jsx-dev-runtime.js?v=d572fda9";
export const Header = () => _jsxDEV("header", {
  className: "bg-accent-400 flex h-12 flex-row justify-between overflow-auto shadow",
  children: [_jsxDEV("h1", {
    className: "my-auto px-4 text-3xl font-bold leading-10",
    children: "Fuel Calculator"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 3,
    columnNumber: 3
  }, void 0), _jsxDEV("nav", {
    className: "my-auto flex px-4 leading-10",
    children: _jsxDEV("a", {
      href: "../",
      className: "hover:bg-accent-600 block",
      children: "Home"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 4
    }, void 0)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 3
  }, void 0)]
}, void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 2,
  columnNumber: 2
}, void 0);
_c = Header;
var _c;
$RefreshReg$(_c, "Header");

        if (import.meta.hot) {
          self.$RefreshReg$ = prevRefreshReg;
          self.$RefreshSig$ = prevRefreshSig;
          import.meta.hot.accept((m) => {
            try {
              flushUpdates();
            } catch (e) {
              self.location.reload();
            }
          });
        }
      
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFBTyxhQUFNQSxTQUFTQSxNQUNyQkMsUUFBQTtFQUFRQyxXQUFVO0VBQXVFQyxVQUFBLENBQ3hGRixRQUFBO0lBQUlDLFdBQVU7SUFBNENDLFVBQUM7RUFFM0Q7SUFBQUMsVUFBQUM7SUFBQUMsWUFBQTtJQUFBQyxjQUFBO0VBQUEsU0FBSSxHQUNKTixRQUFBO0lBQUtDLFdBQVU7SUFBOEJDLFVBQzVDRixRQUFBO01BQUdPLE1BQUs7TUFBTU4sV0FBVTtNQUEyQkMsVUFBQztJQUVwRDtNQUFBQyxVQUFBQztNQUFBQyxZQUFBO01BQUFDLGNBQUE7SUFBQSxTQUFHO0VBQUM7SUFBQUgsVUFBQUM7SUFBQUMsWUFBQTtJQUFBQyxjQUFBO0VBQUEsU0FDQSxDQUFDO0FBQUE7RUFBQUgsVUFBQUM7RUFBQUMsWUFBQTtFQUFBQyxjQUFBO0FBQUEsU0FDQztBQUFBRSxFQUFBLEdBVklUO0FBQUFBO0FBQUFBIiwibmFtZXMiOlsiSGVhZGVyIiwiX2pzeERFViIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwiZmlsZU5hbWUiLCJfanN4RmlsZU5hbWUiLCJsaW5lTnVtYmVyIiwiY29sdW1uTnVtYmVyIiwiaHJlZiIsIl9jIl0sInNvdXJjZXMiOlsiSGVhZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgSGVhZGVyID0gKCkgPT4gKFxuXHQ8aGVhZGVyIGNsYXNzTmFtZT1cImJnLWFjY2VudC00MDAgZmxleCBoLTEyIGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBvdmVyZmxvdy1hdXRvIHNoYWRvd1wiPlxuXHRcdDxoMSBjbGFzc05hbWU9XCJteS1hdXRvIHB4LTQgdGV4dC0zeGwgZm9udC1ib2xkIGxlYWRpbmctMTBcIj5cblx0XHRcdEZ1ZWwgQ2FsY3VsYXRvclxuXHRcdDwvaDE+XG5cdFx0PG5hdiBjbGFzc05hbWU9XCJteS1hdXRvIGZsZXggcHgtNCBsZWFkaW5nLTEwXCI+XG5cdFx0XHQ8YSBocmVmPVwiLi4vXCIgY2xhc3NOYW1lPVwiaG92ZXI6YmctYWNjZW50LTYwMCBibG9ja1wiPlxuXHRcdFx0XHRIb21lXG5cdFx0XHQ8L2E+XG5cdFx0PC9uYXY+XG5cdDwvaGVhZGVyPlxuKVxuIl0sImZpbGUiOiIvVXNlcnMvamVhbm1pY2hlbC5mcmFuY29pcy9naXRodWIvam1mcmFuY29pcy91aS9hcHAvZnVlbGNhbGMvc3JjL2NvbXBvbmVudHMvSGVhZGVyLnRzeCJ9