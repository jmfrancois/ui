import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Form.tsx");        import "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+core@1.5.2_preact@10.19.3/node_modules/@prefresh/core/src/index.js?v=6c2cbf74";        import { flush as flushUpdates } from "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+utils@1.2.0/node_modules/@prefresh/utils/src/index.js?v=6c2cbf74";        let prevRefreshReg;        let prevRefreshSig;        if (import.meta.hot) {          prevRefreshReg = self.$RefreshReg$ || (() => {});          prevRefreshSig = self.$RefreshSig$ || (() => (type) => type);          self.$RefreshReg$ = (type, id) => {            self.__PREFRESH__.register(type, "/Users/jeanmichel.francois/github/jmfrancois/ui/app/fuelcalc/src/components/Form.tsx" + " " + id);          };          self.$RefreshSig$ = () => {            let status = 'begin';            let savedType;            return (type, key, forceReset, getCustomHooks) => {              if (!savedType) savedType = type;              status = self.__PREFRESH__.sign(type || savedType, key, forceReset, getCustomHooks, status);              return type;            };          };        }        var _s = $RefreshSig$(),
  _s2 = $RefreshSig$();
var _jsxFileName = "/Users/jeanmichel.francois/github/jmfrancois/ui/app/fuelcalc/src/components/Form.tsx";
import { addHookName } from "/node_modules/.vite/deps/preact_devtools.js?v=d572fda9";
import { useState, useEffect } from "/node_modules/.vite/deps/preact_hooks.js?v=035fd81c";
import { jsxDEV as _jsxDEV } from "/node_modules/.vite/deps/preact_jsx-dev-runtime.js?v=d572fda9";
class State {
  constructor(prev) {
    this.laptimeM = 2;
    this.laptimeS = 10;
    this.raceLength = 20;
    this.literPerLap = 2.6;
    this.maxTank = 105;
    this.onChange = () => {};
    if (prev) {
      this.setState = prev.setState;
      this.laptimeM = prev.laptimeM;
      this.laptimeS = prev.laptimeS;
      this.raceLength = prev.raceLength;
      this.literPerLap = prev.literPerLap;
      this.maxTank = prev.maxTank;
      this.onChange = prev.onChange;
    }
    this.compute();
  }
  set(attr, value) {
    let v = value;
    if (typeof value === "string") {
      if (value.indexOf(".") !== -1) {
        v = parseFloat(value);
      } else {
        v = parseInt(value, 10);
      }
    }
    console.log(`set attr ${attr} ${value} => ${v}`);
    if (!isNaN(v)) {
      this[attr] = v;
      this.compute();
      this.onChange();
    } else {
      console.error(`Try to set ${attr} to a value which is not a number`);
    }
  }
  compute() {
    this.laps = this.raceLength * 60 / (this.laptimeM * 60 + this.laptimeS + 0.5) + 1;
    this.litersTotal = this.laps * this.literPerLap + 1.5;
    this.pitstopRequired = this.litersTotal / this.maxTank;
    this.possibleLapsOnTank = this.maxTank / this.literPerLap - 0.5;
  }
}
_c = State;
function useCalc() {
  _s();
  const [state, setState] = addHookName(useState(new State()), "state");
  useEffect(() => {
    state.onChange = () => setState(new State(state));
  }, [state]);
  return state;
}
_s(useCalc, "aXxOboMzAV4RDkJYBFFyI46NkwY=");
function format(n) {
  return Math.floor(n);
}
function onChange(event, state) {
  console.log(state);
  state.set(event.target.name, event.target.value);
}
export const Calc = () => {
  _s2();
  const state = useCalc();
  return _jsxDEV("form", {
    className: "max-w  grid grid-cols-1 gap-2 bg-neutral-200/75 px-2 sm:grid-cols-2 dark:bg-neutral-800/75",
    children: [_jsxDEV("div", {
      className: "",
      children: [_jsxDEV("div", {
        className: "",
        children: [_jsxDEV("label", {
          className: "text-m mb-2 block font-medium text-gray-900 dark:text-white",
          children: "Lap time (minutes / seconds)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 86,
          columnNumber: 6
        }, void 0), _jsxDEV("div", {
          className: "mb-2 grid grid-cols-2 gap-2",
          children: [_jsxDEV("input", {
            type: "number",
            className: "block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500",
            value: state.laptimeM,
            autoFocus: true,
            name: "laptimeM",
            onChange: e => onChange(e, state)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 90,
            columnNumber: 7
          }, void 0), _jsxDEV("input", {
            type: "number",
            className: "block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500",
            value: state.laptimeS,
            name: "laptimeS",
            onChange: e => onChange(e, state)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 98,
            columnNumber: 7
          }, void 0)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 89,
          columnNumber: 6
        }, void 0)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 5
      }, void 0), _jsxDEV("div", {
        className: "mb-2 flex flex-col",
        children: [_jsxDEV("label", {
          className: "text-m mb-2 block font-medium text-gray-900 dark:text-white",
          children: "Race length (minutes)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 109,
          columnNumber: 6
        }, void 0), _jsxDEV("input", {
          type: "number",
          className: "block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500",
          value: state.raceLength,
          name: "raceLength",
          onChange: e => onChange(e, state)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 112,
          columnNumber: 6
        }, void 0)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 108,
        columnNumber: 5
      }, void 0), _jsxDEV("div", {
        className: "mb-2 flex flex-col",
        children: [_jsxDEV("label", {
          className: "text-m mb-2 block font-medium text-gray-900 dark:text-white",
          children: "Consumption (liters/lap)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 121,
          columnNumber: 6
        }, void 0), _jsxDEV("input", {
          type: "number",
          className: "block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500",
          value: state.literPerLap,
          name: "literPerLap",
          onChange: e => onChange(e, state)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 124,
          columnNumber: 6
        }, void 0)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 120,
        columnNumber: 5
      }, void 0), _jsxDEV("div", {
        className: "mb-2 flex flex-col",
        children: [_jsxDEV("label", {
          className: "text-m mb-2 block font-medium text-gray-900 dark:text-white",
          children: "Max tank capacity (liters)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 133,
          columnNumber: 6
        }, void 0), _jsxDEV("input", {
          type: "number",
          className: "block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500",
          value: state.maxTank,
          name: "maxTank",
          onChange: e => onChange(e, state)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 136,
          columnNumber: 6
        }, void 0)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 5
      }, void 0)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 4
    }, void 0), _jsxDEV("div", {
      className: "",
      children: [_jsxDEV("div", {
        className: "mb-2 flex flex-col",
        children: [_jsxDEV("label", {
          className: "text-m mb-2 block font-medium text-gray-900 dark:text-white",
          children: "Total fuel needed (liters)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 147,
          columnNumber: 6
        }, void 0), _jsxDEV("input", {
          type: "number",
          className: "block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500",
          value: format(state.litersTotal),
          name: "litersTotal",
          readOnly: true
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 150,
          columnNumber: 6
        }, void 0)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 146,
        columnNumber: 5
      }, void 0), _jsxDEV("div", {
        className: "mb-2 flex flex-col",
        children: [_jsxDEV("label", {
          className: "text-m mb-2 block font-medium text-gray-900 dark:text-white",
          children: "Total Laps (with formation lap)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 159,
          columnNumber: 6
        }, void 0), _jsxDEV("input", {
          type: "number",
          className: "block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500",
          value: format(state.laps),
          readOnly: true
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 162,
          columnNumber: 6
        }, void 0)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 158,
        columnNumber: 5
      }, void 0), _jsxDEV("div", {
        className: "mb-2 flex flex-col",
        children: [_jsxDEV("label", {
          className: "text-m mb-2 block font-medium text-gray-900 dark:text-white",
          children: "Number of pit stop required"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 170,
          columnNumber: 6
        }, void 0), _jsxDEV("input", {
          type: "number",
          className: "block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500",
          value: format(state.pitstopRequired),
          readOnly: true
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 173,
          columnNumber: 6
        }, void 0)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 169,
        columnNumber: 5
      }, void 0), _jsxDEV("div", {
        className: "mb-2 flex flex-col",
        children: [_jsxDEV("label", {
          className: "text-m mb-2 block font-medium text-gray-900 dark:text-white",
          children: "Possible laps on tank"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 181,
          columnNumber: 6
        }, void 0), _jsxDEV("input", {
          type: "number",
          className: "block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500",
          value: format(state.possibleLapsOnTank),
          readOnly: true
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 184,
          columnNumber: 6
        }, void 0)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 180,
        columnNumber: 5
      }, void 0)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 145,
      columnNumber: 4
    }, void 0)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 83,
    columnNumber: 3
  }, void 0);
};
_s2(Calc, "pS+ykK0orMTxWUSW82IMLCgX3cM=", false, function () {
  return [useCalc];
});
_c2 = Calc;
var _c, _c2;
$RefreshReg$(_c, "State");
$RefreshReg$(_c2, "Calc");

        if (import.meta.hot) {
          self.$RefreshReg$ = prevRefreshReg;
          self.$RefreshSig$ = prevRefreshSig;
          import.meta.hot.accept((m) => {
            try {
              flushUpdates();
            } catch (e) {
              self.location.reload();
            }
          });
        }
      
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7OztBQUFBLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUFjLFNBQUFDLFVBQUFDLGVBQUE7QUFFbEQsTUFBTUMsTUFBTTtFQWFYQyxZQUFZQyxNQUFjO0lBQ3pCLEtBQUtDLFdBQVc7SUFDaEIsS0FBS0MsV0FBVztJQUNoQixLQUFLQyxhQUFhO0lBQ2xCLEtBQUtDLGNBQWM7SUFDbkIsS0FBS0MsVUFBVTtJQUNmLEtBQUtDLFdBQVcsTUFBTSxDQUFDO0lBQ3ZCLElBQUlOLE1BQU07TUFDVCxLQUFLTyxXQUFXUCxLQUFLTztNQUNyQixLQUFLTixXQUFXRCxLQUFLQztNQUNyQixLQUFLQyxXQUFXRixLQUFLRTtNQUNyQixLQUFLQyxhQUFhSCxLQUFLRztNQUN2QixLQUFLQyxjQUFjSixLQUFLSTtNQUN4QixLQUFLQyxVQUFVTCxLQUFLSztNQUNwQixLQUFLQyxXQUFXTixLQUFLTTtJQUN0QjtJQUVBLEtBQUtFLFFBQVE7RUFDZDtFQUVBQyxJQUFJQyxNQUFNQyxPQUFPO0lBQ2hCLElBQUlDLElBQUlEO0lBQ1IsSUFBSSxPQUFPQSxVQUFVLFVBQVU7TUFDOUIsSUFBSUEsTUFBTUUsUUFBUSxHQUFHLE1BQU0sSUFBSTtRQUM5QkQsSUFBSUUsV0FBV0gsS0FBSztNQUNyQixPQUFPO1FBQ05DLElBQUlHLFNBQVNKLE9BQU8sRUFBRTtNQUN2QjtJQUNEO0lBQ0FLLFFBQVFDLElBQUssWUFBV1AsSUFBSyxJQUFHQyxLQUFNLE9BQU1DLENBQUUsRUFBQztJQUMvQyxJQUFJLENBQUNNLE1BQU1OLENBQUMsR0FBRztNQUNkLEtBQUtGLElBQUksSUFBSUU7TUFDYixLQUFLSixRQUFRO01BQ2IsS0FBS0YsU0FBUztJQUNmLE9BQU87TUFDTlUsUUFBUUcsTUFBTyxjQUFhVCxJQUFLLG1DQUFrQztJQUNwRTtFQUNEO0VBQ0FGLFVBQVU7SUFDVCxLQUFLWSxPQUNILEtBQUtqQixhQUFhLE1BQU8sS0FBS0YsV0FBVyxLQUFLLEtBQUtDLFdBQVcsT0FBTztJQUN2RSxLQUFLbUIsY0FBYyxLQUFLRCxPQUFPLEtBQUtoQixjQUFjO0lBQ2xELEtBQUtrQixrQkFBa0IsS0FBS0QsY0FBYyxLQUFLaEI7SUFDL0MsS0FBS2tCLHFCQUFxQixLQUFLbEIsVUFBVSxLQUFLRCxjQUFjO0VBQzdEO0FBQ0Q7QUFBQW9CLEVBQUEsR0ExRE0xQjtBQTRETixTQUFTMkIsVUFBVTtFQUFBQyxFQUFBO0VBQ2xCLE1BQU0sQ0FBQ0MsT0FBT3BCLFFBQVEsSUFBQ3FCLFlBQUdsQyxTQUFnQixJQUFJSSxNQUFNLENBQUMsR0FBQztFQUN0REgsVUFBVSxNQUFNO0lBQ2ZnQyxNQUFNckIsV0FBVyxNQUFNQyxTQUFTLElBQUlULE1BQU02QixLQUFLLENBQUM7RUFDakQsR0FBRyxDQUFDQSxLQUFLLENBQUM7RUFDVixPQUFPQTtBQUNSO0FBQUFELEVBQUEsQ0FOU0Q7QUFRVCxTQUFTSSxPQUFPQyxHQUFXO0VBQzFCLE9BQU9DLEtBQUtDLE1BQU1GLENBQUM7QUFDcEI7QUFFQSxTQUFTeEIsU0FBUzJCLE9BQU9OLE9BQU87RUFDL0JYLFFBQVFDLElBQUlVLEtBQUs7RUFDakJBLE1BQU1sQixJQUFJd0IsTUFBTUMsT0FBT0MsTUFBTUYsTUFBTUMsT0FBT3ZCLEtBQUs7QUFDaEQ7QUFFTyxhQUFNeUIsT0FBT0EsTUFBTTtFQUFBQyxHQUFBO0VBQ3pCLE1BQU1WLFFBQVFGLFFBQVE7RUFDdEIsT0FDQzVCLFFBQUE7SUFBTXlDLFdBQVU7SUFBNEZDLFVBQUEsQ0FDM0cxQyxRQUFBO01BQUt5QyxXQUFVO01BQUVDLFVBQUEsQ0FDaEIxQyxRQUFBO1FBQUt5QyxXQUFVO1FBQUVDLFVBQUEsQ0FDaEIxQyxRQUFBO1VBQU95QyxXQUFVO1VBQTZEQyxVQUFDO1FBRS9FO1VBQUFDLFVBQUFDO1VBQUFDLFlBQUE7VUFBQUMsY0FBQTtRQUFBLFNBQU8sR0FDUDlDLFFBQUE7VUFBS3lDLFdBQVU7VUFBNkJDLFVBQUEsQ0FDM0MxQyxRQUFBO1lBQ0MrQyxNQUFLO1lBQ0xOLFdBQVU7WUFDVjNCLE9BQU9nQixNQUFNMUI7WUFDYjRDLFdBQVM7WUFDVFYsTUFBSztZQUNMN0IsVUFBV3dDLEtBQU14QyxTQUFTd0MsR0FBR25CLEtBQUs7VUFBRTtZQUFBYSxVQUFBQztZQUFBQyxZQUFBO1lBQUFDLGNBQUE7VUFBQSxTQUNwQyxHQUNEOUMsUUFBQTtZQUNDK0MsTUFBSztZQUNMTixXQUFVO1lBQ1YzQixPQUFPZ0IsTUFBTXpCO1lBQ2JpQyxNQUFLO1lBQ0w3QixVQUFXd0MsS0FBTXhDLFNBQVN3QyxHQUFHbkIsS0FBSztVQUFFO1lBQUFhLFVBQUFDO1lBQUFDLFlBQUE7WUFBQUMsY0FBQTtVQUFBLFNBQ3BDLENBQUM7UUFBQTtVQUFBSCxVQUFBQztVQUFBQyxZQUFBO1VBQUFDLGNBQUE7UUFBQSxTQUNFLENBQUM7TUFBQTtRQUFBSCxVQUFBQztRQUFBQyxZQUFBO1FBQUFDLGNBQUE7TUFBQSxTQUNGLEdBRUw5QyxRQUFBO1FBQUt5QyxXQUFVO1FBQW9CQyxVQUFBLENBQ2xDMUMsUUFBQTtVQUFPeUMsV0FBVTtVQUE2REMsVUFBQztRQUUvRTtVQUFBQyxVQUFBQztVQUFBQyxZQUFBO1VBQUFDLGNBQUE7UUFBQSxTQUFPLEdBQ1A5QyxRQUFBO1VBQ0MrQyxNQUFLO1VBQ0xOLFdBQVU7VUFDVjNCLE9BQU9nQixNQUFNeEI7VUFDYmdDLE1BQUs7VUFDTDdCLFVBQVd3QyxLQUFNeEMsU0FBU3dDLEdBQUduQixLQUFLO1FBQUU7VUFBQWEsVUFBQUM7VUFBQUMsWUFBQTtVQUFBQyxjQUFBO1FBQUEsU0FDcEMsQ0FBQztNQUFBO1FBQUFILFVBQUFDO1FBQUFDLFlBQUE7UUFBQUMsY0FBQTtNQUFBLFNBQ0UsR0FDTDlDLFFBQUE7UUFBS3lDLFdBQVU7UUFBb0JDLFVBQUEsQ0FDbEMxQyxRQUFBO1VBQU95QyxXQUFVO1VBQTZEQyxVQUFDO1FBRS9FO1VBQUFDLFVBQUFDO1VBQUFDLFlBQUE7VUFBQUMsY0FBQTtRQUFBLFNBQU8sR0FDUDlDLFFBQUE7VUFDQytDLE1BQUs7VUFDTE4sV0FBVTtVQUNWM0IsT0FBT2dCLE1BQU12QjtVQUNiK0IsTUFBSztVQUNMN0IsVUFBV3dDLEtBQU14QyxTQUFTd0MsR0FBR25CLEtBQUs7UUFBRTtVQUFBYSxVQUFBQztVQUFBQyxZQUFBO1VBQUFDLGNBQUE7UUFBQSxTQUNwQyxDQUFDO01BQUE7UUFBQUgsVUFBQUM7UUFBQUMsWUFBQTtRQUFBQyxjQUFBO01BQUEsU0FDRSxHQUNMOUMsUUFBQTtRQUFLeUMsV0FBVTtRQUFvQkMsVUFBQSxDQUNsQzFDLFFBQUE7VUFBT3lDLFdBQVU7VUFBNkRDLFVBQUM7UUFFL0U7VUFBQUMsVUFBQUM7VUFBQUMsWUFBQTtVQUFBQyxjQUFBO1FBQUEsU0FBTyxHQUNQOUMsUUFBQTtVQUNDK0MsTUFBSztVQUNMTixXQUFVO1VBQ1YzQixPQUFPZ0IsTUFBTXRCO1VBQ2I4QixNQUFLO1VBQ0w3QixVQUFXd0MsS0FBTXhDLFNBQVN3QyxHQUFHbkIsS0FBSztRQUFFO1VBQUFhLFVBQUFDO1VBQUFDLFlBQUE7VUFBQUMsY0FBQTtRQUFBLFNBQ3BDLENBQUM7TUFBQTtRQUFBSCxVQUFBQztRQUFBQyxZQUFBO1FBQUFDLGNBQUE7TUFBQSxTQUNFLENBQUM7SUFBQTtNQUFBSCxVQUFBQztNQUFBQyxZQUFBO01BQUFDLGNBQUE7SUFBQSxTQUNGLEdBQ0w5QyxRQUFBO01BQUt5QyxXQUFVO01BQUVDLFVBQUEsQ0FDaEIxQyxRQUFBO1FBQUt5QyxXQUFVO1FBQW9CQyxVQUFBLENBQ2xDMUMsUUFBQTtVQUFPeUMsV0FBVTtVQUE2REMsVUFBQztRQUUvRTtVQUFBQyxVQUFBQztVQUFBQyxZQUFBO1VBQUFDLGNBQUE7UUFBQSxTQUFPLEdBQ1A5QyxRQUFBO1VBQ0MrQyxNQUFLO1VBQ0xOLFdBQVU7VUFDVjNCLE9BQU9rQixPQUFPRixNQUFNTixXQUFXO1VBQy9CYyxNQUFLO1VBQ0xZLFVBQVE7UUFBQTtVQUFBUCxVQUFBQztVQUFBQyxZQUFBO1VBQUFDLGNBQUE7UUFBQSxTQUNSLENBQUM7TUFBQTtRQUFBSCxVQUFBQztRQUFBQyxZQUFBO1FBQUFDLGNBQUE7TUFBQSxTQUNFLEdBQ0w5QyxRQUFBO1FBQUt5QyxXQUFVO1FBQW9CQyxVQUFBLENBQ2xDMUMsUUFBQTtVQUFPeUMsV0FBVTtVQUE2REMsVUFBQztRQUUvRTtVQUFBQyxVQUFBQztVQUFBQyxZQUFBO1VBQUFDLGNBQUE7UUFBQSxTQUFPLEdBQ1A5QyxRQUFBO1VBQ0MrQyxNQUFLO1VBQ0xOLFdBQVU7VUFDVjNCLE9BQU9rQixPQUFPRixNQUFNUCxJQUFJO1VBQ3hCMkIsVUFBUTtRQUFBO1VBQUFQLFVBQUFDO1VBQUFDLFlBQUE7VUFBQUMsY0FBQTtRQUFBLFNBQ1IsQ0FBQztNQUFBO1FBQUFILFVBQUFDO1FBQUFDLFlBQUE7UUFBQUMsY0FBQTtNQUFBLFNBQ0UsR0FDTDlDLFFBQUE7UUFBS3lDLFdBQVU7UUFBb0JDLFVBQUEsQ0FDbEMxQyxRQUFBO1VBQU95QyxXQUFVO1VBQTZEQyxVQUFDO1FBRS9FO1VBQUFDLFVBQUFDO1VBQUFDLFlBQUE7VUFBQUMsY0FBQTtRQUFBLFNBQU8sR0FDUDlDLFFBQUE7VUFDQytDLE1BQUs7VUFDTE4sV0FBVTtVQUNWM0IsT0FBT2tCLE9BQU9GLE1BQU1MLGVBQWU7VUFDbkN5QixVQUFRO1FBQUE7VUFBQVAsVUFBQUM7VUFBQUMsWUFBQTtVQUFBQyxjQUFBO1FBQUEsU0FDUixDQUFDO01BQUE7UUFBQUgsVUFBQUM7UUFBQUMsWUFBQTtRQUFBQyxjQUFBO01BQUEsU0FDRSxHQUNMOUMsUUFBQTtRQUFLeUMsV0FBVTtRQUFvQkMsVUFBQSxDQUNsQzFDLFFBQUE7VUFBT3lDLFdBQVU7VUFBNkRDLFVBQUM7UUFFL0U7VUFBQUMsVUFBQUM7VUFBQUMsWUFBQTtVQUFBQyxjQUFBO1FBQUEsU0FBTyxHQUNQOUMsUUFBQTtVQUNDK0MsTUFBSztVQUNMTixXQUFVO1VBQ1YzQixPQUFPa0IsT0FBT0YsTUFBTUosa0JBQWtCO1VBQ3RDd0IsVUFBUTtRQUFBO1VBQUFQLFVBQUFDO1VBQUFDLFlBQUE7VUFBQUMsY0FBQTtRQUFBLFNBQ1IsQ0FBQztNQUFBO1FBQUFILFVBQUFDO1FBQUFDLFlBQUE7UUFBQUMsY0FBQTtNQUFBLFNBQ0UsQ0FBQztJQUFBO01BQUFILFVBQUFDO01BQUFDLFlBQUE7TUFBQUMsY0FBQTtJQUFBLFNBQ0YsQ0FBQztFQUFBO0lBQUFILFVBQUFDO0lBQUFDLFlBQUE7SUFBQUMsY0FBQTtFQUFBLFNBQ0Q7QUFFUjtBQUFBTixHQUFBLENBbEhhRDtFQUFBQSxRQUNFWDtBQUFBQTtBQUFBQSxNQURGVztBQUFBQTtBQUFBQTtBQUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwianN4REVWIiwiX2pzeERFViIsIlN0YXRlIiwiY29uc3RydWN0b3IiLCJwcmV2IiwibGFwdGltZU0iLCJsYXB0aW1lUyIsInJhY2VMZW5ndGgiLCJsaXRlclBlckxhcCIsIm1heFRhbmsiLCJvbkNoYW5nZSIsInNldFN0YXRlIiwiY29tcHV0ZSIsInNldCIsImF0dHIiLCJ2YWx1ZSIsInYiLCJpbmRleE9mIiwicGFyc2VGbG9hdCIsInBhcnNlSW50IiwiY29uc29sZSIsImxvZyIsImlzTmFOIiwiZXJyb3IiLCJsYXBzIiwibGl0ZXJzVG90YWwiLCJwaXRzdG9wUmVxdWlyZWQiLCJwb3NzaWJsZUxhcHNPblRhbmsiLCJfYyIsInVzZUNhbGMiLCJfcyIsInN0YXRlIiwiYWRkSG9va05hbWUiLCJmb3JtYXQiLCJuIiwiTWF0aCIsImZsb29yIiwiZXZlbnQiLCJ0YXJnZXQiLCJuYW1lIiwiQ2FsYyIsIl9zMiIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwiZmlsZU5hbWUiLCJfanN4RmlsZU5hbWUiLCJsaW5lTnVtYmVyIiwiY29sdW1uTnVtYmVyIiwidHlwZSIsImF1dG9Gb2N1cyIsImUiLCJyZWFkT25seSJdLCJzb3VyY2VzIjpbIkZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdwcmVhY3QvaG9va3MnXG5cbmNsYXNzIFN0YXRlIHtcblx0bGFwdGltZU06IG51bWJlclxuXHRsYXB0aW1lUzogbnVtYmVyXG5cdHJhY2VMZW5ndGg6IG51bWJlclxuXHRsaXRlclBlckxhcDogbnVtYmVyXG5cdG1heFRhbms6IG51bWJlclxuXHRvbkNoYW5nZTogKCkgPT4gdm9pZFxuXHRsYXBzPzogbnVtYmVyXG5cdGxpdGVyc1RvdGFsPzogbnVtYmVyXG5cdHBpdHN0b3BSZXF1aXJlZD86IG51bWJlclxuXHRwb3NzaWJsZUxhcHNPblRhbms/OiBudW1iZXJcblx0c2V0U3RhdGU/OiBTdGF0ZVxuXG5cdGNvbnN0cnVjdG9yKHByZXY/OiBTdGF0ZSkge1xuXHRcdHRoaXMubGFwdGltZU0gPSAyXG5cdFx0dGhpcy5sYXB0aW1lUyA9IDEwXG5cdFx0dGhpcy5yYWNlTGVuZ3RoID0gMjAgLy9taW51dGVzXG5cdFx0dGhpcy5saXRlclBlckxhcCA9IDIuNlxuXHRcdHRoaXMubWF4VGFuayA9IDEwNSAvLyBjYXBhY2l0eVxuXHRcdHRoaXMub25DaGFuZ2UgPSAoKSA9PiB7fVxuXHRcdGlmIChwcmV2KSB7XG5cdFx0XHR0aGlzLnNldFN0YXRlID0gcHJldi5zZXRTdGF0ZVxuXHRcdFx0dGhpcy5sYXB0aW1lTSA9IHByZXYubGFwdGltZU1cblx0XHRcdHRoaXMubGFwdGltZVMgPSBwcmV2LmxhcHRpbWVTXG5cdFx0XHR0aGlzLnJhY2VMZW5ndGggPSBwcmV2LnJhY2VMZW5ndGhcblx0XHRcdHRoaXMubGl0ZXJQZXJMYXAgPSBwcmV2LmxpdGVyUGVyTGFwXG5cdFx0XHR0aGlzLm1heFRhbmsgPSBwcmV2Lm1heFRhbmtcblx0XHRcdHRoaXMub25DaGFuZ2UgPSBwcmV2Lm9uQ2hhbmdlXG5cdFx0fVxuXG5cdFx0dGhpcy5jb21wdXRlKClcblx0fVxuXG5cdHNldChhdHRyLCB2YWx1ZSkge1xuXHRcdGxldCB2ID0gdmFsdWVcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuXHRcdFx0aWYgKHZhbHVlLmluZGV4T2YoJy4nKSAhPT0gLTEpIHtcblx0XHRcdFx0diA9IHBhcnNlRmxvYXQodmFsdWUpXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR2ID0gcGFyc2VJbnQodmFsdWUsIDEwKVxuXHRcdFx0fVxuXHRcdH1cblx0XHRjb25zb2xlLmxvZyhgc2V0IGF0dHIgJHthdHRyfSAke3ZhbHVlfSA9PiAke3Z9YClcblx0XHRpZiAoIWlzTmFOKHYpKSB7XG5cdFx0XHR0aGlzW2F0dHJdID0gdlxuXHRcdFx0dGhpcy5jb21wdXRlKClcblx0XHRcdHRoaXMub25DaGFuZ2UoKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zb2xlLmVycm9yKGBUcnkgdG8gc2V0ICR7YXR0cn0gdG8gYSB2YWx1ZSB3aGljaCBpcyBub3QgYSBudW1iZXJgKVxuXHRcdH1cblx0fVxuXHRjb21wdXRlKCkge1xuXHRcdHRoaXMubGFwcyA9XG5cdFx0XHQodGhpcy5yYWNlTGVuZ3RoICogNjApIC8gKHRoaXMubGFwdGltZU0gKiA2MCArIHRoaXMubGFwdGltZVMgKyAwLjUpICsgMVxuXHRcdHRoaXMubGl0ZXJzVG90YWwgPSB0aGlzLmxhcHMgKiB0aGlzLmxpdGVyUGVyTGFwICsgMS41XG5cdFx0dGhpcy5waXRzdG9wUmVxdWlyZWQgPSB0aGlzLmxpdGVyc1RvdGFsIC8gdGhpcy5tYXhUYW5rXG5cdFx0dGhpcy5wb3NzaWJsZUxhcHNPblRhbmsgPSB0aGlzLm1heFRhbmsgLyB0aGlzLmxpdGVyUGVyTGFwIC0gMC41XG5cdH1cbn1cblxuZnVuY3Rpb24gdXNlQ2FsYygpIHtcblx0Y29uc3QgW3N0YXRlLCBzZXRTdGF0ZV0gPSB1c2VTdGF0ZTxTdGF0ZT4obmV3IFN0YXRlKCkpXG5cdHVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0c3RhdGUub25DaGFuZ2UgPSAoKSA9PiBzZXRTdGF0ZShuZXcgU3RhdGUoc3RhdGUpKVxuXHR9LCBbc3RhdGVdKVxuXHRyZXR1cm4gc3RhdGVcbn1cblxuZnVuY3Rpb24gZm9ybWF0KG46IG51bWJlcikge1xuXHRyZXR1cm4gTWF0aC5mbG9vcihuKVxufVxuXG5mdW5jdGlvbiBvbkNoYW5nZShldmVudCwgc3RhdGUpIHtcblx0Y29uc29sZS5sb2coc3RhdGUpXG5cdHN0YXRlLnNldChldmVudC50YXJnZXQubmFtZSwgZXZlbnQudGFyZ2V0LnZhbHVlKVxufVxuXG5leHBvcnQgY29uc3QgQ2FsYyA9ICgpID0+IHtcblx0Y29uc3Qgc3RhdGUgPSB1c2VDYWxjKClcblx0cmV0dXJuIChcblx0XHQ8Zm9ybSBjbGFzc05hbWU9XCJtYXgtdyAgZ3JpZCBncmlkLWNvbHMtMSBnYXAtMiBiZy1uZXV0cmFsLTIwMC83NSBweC0yIHNtOmdyaWQtY29scy0yIGRhcms6YmctbmV1dHJhbC04MDAvNzVcIj5cblx0XHRcdDxkaXYgY2xhc3NOYW1lPVwiXCI+XG5cdFx0XHRcdDxkaXYgY2xhc3NOYW1lPVwiXCI+XG5cdFx0XHRcdFx0PGxhYmVsIGNsYXNzTmFtZT1cInRleHQtbSBtYi0yIGJsb2NrIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG5cdFx0XHRcdFx0XHRMYXAgdGltZSAobWludXRlcyAvIHNlY29uZHMpXG5cdFx0XHRcdFx0PC9sYWJlbD5cblx0XHRcdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiPlxuXHRcdFx0XHRcdFx0PGlucHV0XG5cdFx0XHRcdFx0XHRcdHR5cGU9XCJudW1iZXJcIlxuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktNTAgcC0yLjUgdGV4dC1zbSB0ZXh0LWdyYXktOTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLWJsdWUtNTAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6YmctZ3JheS03MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6cGxhY2Vob2xkZXItZ3JheS00MDAgZGFyazpmb2N1czpib3JkZXItYmx1ZS01MDAgZGFyazpmb2N1czpyaW5nLWJsdWUtNTAwXCJcblx0XHRcdFx0XHRcdFx0dmFsdWU9e3N0YXRlLmxhcHRpbWVNfVxuXHRcdFx0XHRcdFx0XHRhdXRvRm9jdXNcblx0XHRcdFx0XHRcdFx0bmFtZT1cImxhcHRpbWVNXCJcblx0XHRcdFx0XHRcdFx0b25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShlLCBzdGF0ZSl9XG5cdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdFx0PGlucHV0XG5cdFx0XHRcdFx0XHRcdHR5cGU9XCJudW1iZXJcIlxuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktNTAgcC0yLjUgdGV4dC1zbSB0ZXh0LWdyYXktOTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLWJsdWUtNTAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6YmctZ3JheS03MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6cGxhY2Vob2xkZXItZ3JheS00MDAgZGFyazpmb2N1czpib3JkZXItYmx1ZS01MDAgZGFyazpmb2N1czpyaW5nLWJsdWUtNTAwXCJcblx0XHRcdFx0XHRcdFx0dmFsdWU9e3N0YXRlLmxhcHRpbWVTfVxuXHRcdFx0XHRcdFx0XHRuYW1lPVwibGFwdGltZVNcIlxuXHRcdFx0XHRcdFx0XHRvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKGUsIHN0YXRlKX1cblx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdDwvZGl2PlxuXG5cdFx0XHRcdDxkaXYgY2xhc3NOYW1lPVwibWItMiBmbGV4IGZsZXgtY29sXCI+XG5cdFx0XHRcdFx0PGxhYmVsIGNsYXNzTmFtZT1cInRleHQtbSBtYi0yIGJsb2NrIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG5cdFx0XHRcdFx0XHRSYWNlIGxlbmd0aCAobWludXRlcylcblx0XHRcdFx0XHQ8L2xhYmVsPlxuXHRcdFx0XHRcdDxpbnB1dFxuXHRcdFx0XHRcdFx0dHlwZT1cIm51bWJlclwiXG5cdFx0XHRcdFx0XHRjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktNTAgcC0yLjUgdGV4dC1zbSB0ZXh0LWdyYXktOTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLWJsdWUtNTAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6YmctZ3JheS03MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6cGxhY2Vob2xkZXItZ3JheS00MDAgZGFyazpmb2N1czpib3JkZXItYmx1ZS01MDAgZGFyazpmb2N1czpyaW5nLWJsdWUtNTAwXCJcblx0XHRcdFx0XHRcdHZhbHVlPXtzdGF0ZS5yYWNlTGVuZ3RofVxuXHRcdFx0XHRcdFx0bmFtZT1cInJhY2VMZW5ndGhcIlxuXHRcdFx0XHRcdFx0b25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShlLCBzdGF0ZSl9XG5cdFx0XHRcdFx0Lz5cblx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdDxkaXYgY2xhc3NOYW1lPVwibWItMiBmbGV4IGZsZXgtY29sXCI+XG5cdFx0XHRcdFx0PGxhYmVsIGNsYXNzTmFtZT1cInRleHQtbSBtYi0yIGJsb2NrIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG5cdFx0XHRcdFx0XHRDb25zdW1wdGlvbiAobGl0ZXJzL2xhcClcblx0XHRcdFx0XHQ8L2xhYmVsPlxuXHRcdFx0XHRcdDxpbnB1dFxuXHRcdFx0XHRcdFx0dHlwZT1cIm51bWJlclwiXG5cdFx0XHRcdFx0XHRjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktNTAgcC0yLjUgdGV4dC1zbSB0ZXh0LWdyYXktOTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLWJsdWUtNTAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6YmctZ3JheS03MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6cGxhY2Vob2xkZXItZ3JheS00MDAgZGFyazpmb2N1czpib3JkZXItYmx1ZS01MDAgZGFyazpmb2N1czpyaW5nLWJsdWUtNTAwXCJcblx0XHRcdFx0XHRcdHZhbHVlPXtzdGF0ZS5saXRlclBlckxhcH1cblx0XHRcdFx0XHRcdG5hbWU9XCJsaXRlclBlckxhcFwiXG5cdFx0XHRcdFx0XHRvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKGUsIHN0YXRlKX1cblx0XHRcdFx0XHQvPlxuXHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJtYi0yIGZsZXggZmxleC1jb2xcIj5cblx0XHRcdFx0XHQ8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1tIG1iLTIgYmxvY2sgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cblx0XHRcdFx0XHRcdE1heCB0YW5rIGNhcGFjaXR5IChsaXRlcnMpXG5cdFx0XHRcdFx0PC9sYWJlbD5cblx0XHRcdFx0XHQ8aW5wdXRcblx0XHRcdFx0XHRcdHR5cGU9XCJudW1iZXJcIlxuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy1ncmF5LTUwIHAtMi41IHRleHQtc20gdGV4dC1ncmF5LTkwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy1ibHVlLTUwMCBkYXJrOmJvcmRlci1ncmF5LTYwMCBkYXJrOmJnLWdyYXktNzAwIGRhcms6dGV4dC13aGl0ZSBkYXJrOnBsYWNlaG9sZGVyLWdyYXktNDAwIGRhcms6Zm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGRhcms6Zm9jdXM6cmluZy1ibHVlLTUwMFwiXG5cdFx0XHRcdFx0XHR2YWx1ZT17c3RhdGUubWF4VGFua31cblx0XHRcdFx0XHRcdG5hbWU9XCJtYXhUYW5rXCJcblx0XHRcdFx0XHRcdG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2UoZSwgc3RhdGUpfVxuXHRcdFx0XHRcdC8+XG5cdFx0XHRcdDwvZGl2PlxuXHRcdFx0PC9kaXY+XG5cdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cIlwiPlxuXHRcdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgZmxleCBmbGV4LWNvbFwiPlxuXHRcdFx0XHRcdDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LW0gbWItMiBibG9jayBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuXHRcdFx0XHRcdFx0VG90YWwgZnVlbCBuZWVkZWQgKGxpdGVycylcblx0XHRcdFx0XHQ8L2xhYmVsPlxuXHRcdFx0XHRcdDxpbnB1dFxuXHRcdFx0XHRcdFx0dHlwZT1cIm51bWJlclwiXG5cdFx0XHRcdFx0XHRjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktNTAgcC0yLjUgdGV4dC1zbSB0ZXh0LWdyYXktOTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLWJsdWUtNTAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6YmctZ3JheS03MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6cGxhY2Vob2xkZXItZ3JheS00MDAgZGFyazpmb2N1czpib3JkZXItYmx1ZS01MDAgZGFyazpmb2N1czpyaW5nLWJsdWUtNTAwXCJcblx0XHRcdFx0XHRcdHZhbHVlPXtmb3JtYXQoc3RhdGUubGl0ZXJzVG90YWwpfVxuXHRcdFx0XHRcdFx0bmFtZT1cImxpdGVyc1RvdGFsXCJcblx0XHRcdFx0XHRcdHJlYWRPbmx5XG5cdFx0XHRcdFx0Lz5cblx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdDxkaXYgY2xhc3NOYW1lPVwibWItMiBmbGV4IGZsZXgtY29sXCI+XG5cdFx0XHRcdFx0PGxhYmVsIGNsYXNzTmFtZT1cInRleHQtbSBtYi0yIGJsb2NrIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG5cdFx0XHRcdFx0XHRUb3RhbCBMYXBzICh3aXRoIGZvcm1hdGlvbiBsYXApXG5cdFx0XHRcdFx0PC9sYWJlbD5cblx0XHRcdFx0XHQ8aW5wdXRcblx0XHRcdFx0XHRcdHR5cGU9XCJudW1iZXJcIlxuXHRcdFx0XHRcdFx0Y2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy1ncmF5LTUwIHAtMi41IHRleHQtc20gdGV4dC1ncmF5LTkwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy1ibHVlLTUwMCBkYXJrOmJvcmRlci1ncmF5LTYwMCBkYXJrOmJnLWdyYXktNzAwIGRhcms6dGV4dC13aGl0ZSBkYXJrOnBsYWNlaG9sZGVyLWdyYXktNDAwIGRhcms6Zm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGRhcms6Zm9jdXM6cmluZy1ibHVlLTUwMFwiXG5cdFx0XHRcdFx0XHR2YWx1ZT17Zm9ybWF0KHN0YXRlLmxhcHMpfVxuXHRcdFx0XHRcdFx0cmVhZE9ubHlcblx0XHRcdFx0XHQvPlxuXHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJtYi0yIGZsZXggZmxleC1jb2xcIj5cblx0XHRcdFx0XHQ8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1tIG1iLTIgYmxvY2sgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cblx0XHRcdFx0XHRcdE51bWJlciBvZiBwaXQgc3RvcCByZXF1aXJlZFxuXHRcdFx0XHRcdDwvbGFiZWw+XG5cdFx0XHRcdFx0PGlucHV0XG5cdFx0XHRcdFx0XHR0eXBlPVwibnVtYmVyXCJcblx0XHRcdFx0XHRcdGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctZ3JheS01MCBwLTIuNSB0ZXh0LXNtIHRleHQtZ3JheS05MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOnJpbmctYmx1ZS01MDAgZGFyazpib3JkZXItZ3JheS02MDAgZGFyazpiZy1ncmF5LTcwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpwbGFjZWhvbGRlci1ncmF5LTQwMCBkYXJrOmZvY3VzOmJvcmRlci1ibHVlLTUwMCBkYXJrOmZvY3VzOnJpbmctYmx1ZS01MDBcIlxuXHRcdFx0XHRcdFx0dmFsdWU9e2Zvcm1hdChzdGF0ZS5waXRzdG9wUmVxdWlyZWQpfVxuXHRcdFx0XHRcdFx0cmVhZE9ubHlcblx0XHRcdFx0XHQvPlxuXHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJtYi0yIGZsZXggZmxleC1jb2xcIj5cblx0XHRcdFx0XHQ8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1tIG1iLTIgYmxvY2sgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cblx0XHRcdFx0XHRcdFBvc3NpYmxlIGxhcHMgb24gdGFua1xuXHRcdFx0XHRcdDwvbGFiZWw+XG5cdFx0XHRcdFx0PGlucHV0XG5cdFx0XHRcdFx0XHR0eXBlPVwibnVtYmVyXCJcblx0XHRcdFx0XHRcdGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctZ3JheS01MCBwLTIuNSB0ZXh0LXNtIHRleHQtZ3JheS05MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOnJpbmctYmx1ZS01MDAgZGFyazpib3JkZXItZ3JheS02MDAgZGFyazpiZy1ncmF5LTcwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpwbGFjZWhvbGRlci1ncmF5LTQwMCBkYXJrOmZvY3VzOmJvcmRlci1ibHVlLTUwMCBkYXJrOmZvY3VzOnJpbmctYmx1ZS01MDBcIlxuXHRcdFx0XHRcdFx0dmFsdWU9e2Zvcm1hdChzdGF0ZS5wb3NzaWJsZUxhcHNPblRhbmspfVxuXHRcdFx0XHRcdFx0cmVhZE9ubHlcblx0XHRcdFx0XHQvPlxuXHRcdFx0XHQ8L2Rpdj5cblx0XHRcdDwvZGl2PlxuXHRcdDwvZm9ybT5cblx0KVxufVxuIl0sImZpbGUiOiIvVXNlcnMvamVhbm1pY2hlbC5mcmFuY29pcy9naXRodWIvam1mcmFuY29pcy91aS9hcHAvZnVlbGNhbGMvc3JjL2NvbXBvbmVudHMvRm9ybS50c3gifQ==