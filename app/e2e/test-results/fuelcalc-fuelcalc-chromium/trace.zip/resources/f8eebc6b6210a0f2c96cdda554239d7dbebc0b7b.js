import { options } from "/node_modules/.vite/deps/preact.js?v=8b7c1560";
import { vnodesForComponent } from "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+core@1.5.2_preact@10.19.3/node_modules/@prefresh/core/src/runtime/vnodesForComponent.js?v=6c2cbf74";

const oldUnmount = options.unmount;
options.unmount = vnode => {
  const type = (vnode || {}).type;
  if (typeof type === 'function' && vnodesForComponent.has(type)) {
    const vnodes = vnodesForComponent.get(type);
    if (vnodes) {
      const index = vnodes.indexOf(vnode);
      if (index !== -1) {
        vnodes.splice(index, 1);
      }
    }
  }

  if (oldUnmount) oldUnmount(vnode);
};
