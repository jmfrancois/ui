import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");        import "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+core@1.5.2_preact@10.19.3/node_modules/@prefresh/core/src/index.js?v=6c2cbf74";        import { flush as flushUpdates } from "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+utils@1.2.0/node_modules/@prefresh/utils/src/index.js?v=6c2cbf74";        let prevRefreshReg;        let prevRefreshSig;        if (import.meta.hot) {          prevRefreshReg = self.$RefreshReg$ || (() => {});          prevRefreshSig = self.$RefreshSig$ || (() => (type) => type);          self.$RefreshReg$ = (type, id) => {            self.__PREFRESH__.register(type, "/Users/jeanmichel.francois/github/jmfrancois/ui/app/fuelcalc/src/components/App.tsx" + " " + id);          };          self.$RefreshSig$ = () => {            let status = 'begin';            let savedType;            return (type, key, forceReset, getCustomHooks) => {              if (!savedType) savedType = type;              status = self.__PREFRESH__.sign(type || savedType, key, forceReset, getCustomHooks, status);              return type;            };          };        }        var _jsxFileName = "/Users/jeanmichel.francois/github/jmfrancois/ui/app/fuelcalc/src/components/App.tsx";
import { Calc } from "/src/components/Form.tsx";
import { Header } from "/src/components/Header.tsx";
import { Footer } from "/src/components/Footer.tsx";
import { jsxDEV as _jsxDEV } from "/node_modules/.vite/deps/preact_jsx-dev-runtime.js?v=d572fda9";
import { Fragment as _Fragment } from "/node_modules/.vite/deps/preact_jsx-dev-runtime.js?v=d572fda9";
export function App() {
  return _jsxDEV(_Fragment, {
    children: [_jsxDEV("div", {
      className: "",
      children: [_jsxDEV(Header, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 5
      }, this), _jsxDEV(Calc, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 5
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 4
    }, this), _jsxDEV(Footer, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 4
    }, this)]
  }, void 0, true);
}
_c = App;
var _c;
$RefreshReg$(_c, "App");

        if (import.meta.hot) {
          self.$RefreshReg$ = prevRefreshReg;
          self.$RefreshSig$ = prevRefreshSig;
          import.meta.hot.accept((m) => {
            try {
              flushUpdates();
            } catch (e) {
              self.location.reload();
            }
          });
        }
      
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFlBQVk7QUFDckIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxjQUFjO0FBQVUsU0FBQUMsVUFBQUMsZUFBQTtBQUFBLFNBQUFDLFlBQUFDLGlCQUFBO0FBRTFCLGdCQUFTQyxNQUFNO0VBQ3JCLE9BQ0NILFFBQUFFLFdBQUE7SUFBQUUsVUFBQSxDQUNDSixRQUFBO01BQUtLLFdBQVU7TUFBRUQsVUFBQSxDQUNoQkosUUFBQ0gsUUFBTTtRQUFBUyxVQUFBQztRQUFBQyxZQUFBO1FBQUFDLGNBQUE7TUFBQSxPQUFFLEdBQ1RULFFBQUNKLE1BQUk7UUFBQVUsVUFBQUM7UUFBQUMsWUFBQTtRQUFBQyxjQUFBO01BQUEsT0FBRSxDQUFDO0lBQUE7TUFBQUgsVUFBQUM7TUFBQUMsWUFBQTtNQUFBQyxjQUFBO0lBQUEsT0FDSixHQUNMVCxRQUFDRixRQUFNO01BQUFRLFVBQUFDO01BQUFDLFlBQUE7TUFBQUMsY0FBQTtJQUFBLE9BQUUsQ0FBQztFQUFBLGVBQ1Q7QUFFSjtBQUFBQyxFQUFBLEdBVmdCUDtBQUFBQTtBQUFBQSIsIm5hbWVzIjpbIkNhbGMiLCJIZWFkZXIiLCJGb290ZXIiLCJqc3hERVYiLCJfanN4REVWIiwiRnJhZ21lbnQiLCJfRnJhZ21lbnQiLCJBcHAiLCJjaGlsZHJlbiIsImNsYXNzTmFtZSIsImZpbGVOYW1lIiwiX2pzeEZpbGVOYW1lIiwibGluZU51bWJlciIsImNvbHVtbk51bWJlciIsIl9jIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDYWxjIH0gZnJvbSAnLi9Gb3JtJ1xuaW1wb3J0IHsgSGVhZGVyIH0gZnJvbSAnLi9IZWFkZXInXG5pbXBvcnQgeyBGb290ZXIgfSBmcm9tICcuL0Zvb3RlcidcblxuZXhwb3J0IGZ1bmN0aW9uIEFwcCgpIHtcblx0cmV0dXJuIChcblx0XHQ8PlxuXHRcdFx0PGRpdiBjbGFzc05hbWU9XCJcIj5cblx0XHRcdFx0PEhlYWRlciAvPlxuXHRcdFx0XHQ8Q2FsYyAvPlxuXHRcdFx0PC9kaXY+XG5cdFx0XHQ8Rm9vdGVyIC8+XG5cdFx0PC8+XG5cdClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2plYW5taWNoZWwuZnJhbmNvaXMvZ2l0aHViL2ptZnJhbmNvaXMvdWkvYXBwL2Z1ZWxjYWxjL3NyYy9jb21wb25lbnRzL0FwcC50c3gifQ==