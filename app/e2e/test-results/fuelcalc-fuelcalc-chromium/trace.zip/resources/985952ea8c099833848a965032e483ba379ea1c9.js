import {
  t
} from "/node_modules/.vite/deps/chunk-DAE6426O.js?v=6c2cbf74";
import "/node_modules/.vite/deps/chunk-4Y5524DS.js?v=6c2cbf74";
export {
  t as addHookName
};
//# sourceMappingURL=preact_devtools.js.map
