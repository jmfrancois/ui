import {
  b,
  g,
  l
} from "/node_modules/.vite/deps/chunk-4Y5524DS.js?v=6c2cbf74";

// ../../node_modules/.pnpm/preact@10.19.3/node_modules/preact/devtools/dist/devtools.module.js
function t(o, e) {
  return l.__a && l.__a(e), o;
}
"undefined" != typeof window && window.__PREACT_DEVTOOLS__ && window.__PREACT_DEVTOOLS__.attachPreact("10.19.3", l, { Fragment: g, Component: b });

export {
  t
};
//# sourceMappingURL=chunk-DAE6426O.js.map
