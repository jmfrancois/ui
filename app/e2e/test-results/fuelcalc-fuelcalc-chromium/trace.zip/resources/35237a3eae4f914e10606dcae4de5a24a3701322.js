import { options } from "/node_modules/.vite/deps/preact.js?v=8b7c1560";

import { RERENDER_COUNT } from "/@fs/Users/jeanmichel.francois/github/jmfrancois/ui/node_modules/.pnpm/@prefresh+core@1.5.2_preact@10.19.3/node_modules/@prefresh/core/src/constants.js?v=6c2cbf74";

const defer =
  typeof Promise == 'function'
    ? Promise.prototype.then.bind(Promise.resolve())
    : setTimeout;

options.debounceRendering = process => {
  defer(() => {
    try {
      process();
    } catch (e) {
      process[RERENDER_COUNT] = 0;
      throw e;
    }
  });
};
